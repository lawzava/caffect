<div>
    <div class="alert alert-info mb-4">
        Fill in the form. Choose the country United States, then state, and cities list will be updated.
    </div>
    <form wire:submit.prevent="storeCompany" class="mb-5">
        <div class="form-group row">
            <label for="name" class="col-md-4 col-form-label text-md-right">Company Name*</label>

            <div class="col-md-6">
                <input wire:model="name" type="text" class="form-control" required />
            </div>
        </div>

        <div class="form-group row">
            <label for="country" class="col-md-4 col-form-label text-md-right">Country*</label>

            <div class="col-md-6">
                <select wire:model="selectedCountry" name="country" class="form-control" required>
                    <option value="">-- choose country --</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group row">
            <label for="state" class="col-md-4 col-form-label text-md-right">State*</label>

            <div class="col-md-6">
                <select wire:model="selectedState" name="state" class="form-control" required>
                    <?php if($states->count() == 0): ?>
                        <option value="">-- choose country first --</option>
                    <?php endif; ?>
                    <option value="">-- choose state --</option>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group row">
            <label for="city" class="col-md-4 col-form-label text-md-right">City*</label>

            <div class="col-md-6">
                <select wire:model="selectedCity" name="city" class="form-control" required>
                    <?php if($cities->count() == 0): ?>
                        <option value="">-- choose state first --</option>
                    <?php endif; ?>
                    <option value="">-- choose city --</option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group row mb-0">
            <div class="col-md-8 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    Add Company
                </button>
            </div>
        </div>
    </form>

    <hr />

    <h3>Latest Companies</h3>

    <table class="table">
        <thead>
        <tr>
            <th>Name</th>
            <th>City</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($company->name); ?></td>
                <td><?php echo e($company->city->name); ?>, <?php echo e($company->city->state->name); ?>, <?php echo e($company->city->state->country->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/livewire/bootstrap/companies.blade.php ENDPATH**/ ?>