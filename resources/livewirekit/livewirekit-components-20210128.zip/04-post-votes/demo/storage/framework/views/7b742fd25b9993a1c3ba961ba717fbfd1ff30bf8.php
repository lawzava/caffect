<div class="text-center">
    <a wire:click.prevent="vote(1)" href="#"><i class="fa fa-2x fa-sort-asc" aria-hidden="true"></i></a>
    <div class="text-3xl"><?php echo e($sumVotes); ?></div>
    <a wire:click.prevent="vote(-1)" href="#"><i class="fa fa-2x fa-sort-desc" aria-hidden="true"></i></a>
</div>

<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/livewire/tailwind/post-votes.blade.php ENDPATH**/ ?>