<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet" />

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
<div id="app">
    <main class="py-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header"><h3>Upvoting/Downvoting Posts: Bootstrap Version</h3></div>

                        <div class="card-body">
                            <?php $__currentLoopData = \App\Models\Post::with('votes')->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-1">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post-votes', ['post' => $post, 'designTemplate' => 'bootstrap'])->html();
} elseif ($_instance->childHasBeenRendered('VGgE4Yh')) {
    $componentId = $_instance->getRenderedChildComponentId('VGgE4Yh');
    $componentTag = $_instance->getRenderedChildComponentTagName('VGgE4Yh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VGgE4Yh');
} else {
    $response = \Livewire\Livewire::mount('post-votes', ['post' => $post, 'designTemplate' => 'bootstrap']);
    $html = $response->html();
    $_instance->logRenderedChild('VGgE4Yh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                    <div class="col-11">
                                        <h3><?php echo e($post->title); ?></h3>
                                        <p class="mb-1"><?php echo e(\Illuminate\Support\Str::words($post->post_text, 30)); ?></p>
                                    </div>
                                </div>
                                <hr />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="mt-3 text-center">
                        <a href="<?php echo e(route('tailwind')); ?>">See Tailwind version</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/bootstrap.blade.php ENDPATH**/ ?>