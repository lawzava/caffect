<?php return array (
  'post-votes' => 'App\\Http\\Livewire\\PostVotes',
);