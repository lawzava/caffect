<?php return array (
  'products' => 'App\\Http\\Livewire\\Products',
);