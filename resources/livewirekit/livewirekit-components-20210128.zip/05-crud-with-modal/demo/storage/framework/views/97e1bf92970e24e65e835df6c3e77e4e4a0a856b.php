<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>CRUD with Modal Form</title>

    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet" />

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body class="bg-gray-100">
<div class="font-sans text-gray-900 antialiased">
    <div class="flex flex-col sm:justify-center items-center pt-5 pb-5">
        <h2 class="font-bold text-2xl">CRUD with Modal Form: Tailwind Version</h2>

        <div class="w-full sm:max-w-2xl mt-6 mb-6 px-6 py-8 bg-white shadow-md overflow-hidden sm:rounded-lg">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('products')->html();
} elseif ($_instance->childHasBeenRendered('n9PLkq2')) {
    $componentId = $_instance->getRenderedChildComponentId('n9PLkq2');
    $componentTag = $_instance->getRenderedChildComponentTagName('n9PLkq2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('n9PLkq2');
} else {
    $response = \Livewire\Livewire::mount('products');
    $html = $response->html();
    $_instance->logRenderedChild('n9PLkq2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <a href="<?php echo e(route('bootstrap')); ?>">See Bootstrap version</a>
    </div>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>


</body>
</html>
<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/tailwind.blade.php ENDPATH**/ ?>