<div>
    <div class="form-group row">
        <label for="country" class="col-md-4 col-form-label text-md-right">Country</label>

        <div class="col-md-6">
            <select wire:model="country" name="country" class="form-control">
                <option value="">-- choose country --</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="city" class="col-md-4 col-form-label text-md-right">City</label>

        <div class="col-md-6">
            <select wire:model="city" name="city" class="form-control">
                <?php if($cities->count() == 0): ?>
                    <option value="">-- choose country first --</option>
                <?php endif; ?>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/livewire/bootstrap/country-city.blade.php ENDPATH**/ ?>