<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Posts: Generate Slug from Title</title>

    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body class="bg-gray-100">
<div class="font-sans text-gray-900 antialiased">
    <div class="flex flex-col sm:justify-center items-center pt-5 pb-5">
        <h2 class="font-bold text-2xl">Posts: Generate Slug from Title: Tailwind Version</h2>

        <div class="w-full sm:max-w-xl mt-6 mb-6 px-6 py-8 bg-white shadow-md overflow-hidden sm:rounded-lg">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('posts')->html();
} elseif ($_instance->childHasBeenRendered('RG1OU0i')) {
    $componentId = $_instance->getRenderedChildComponentId('RG1OU0i');
    $componentTag = $_instance->getRenderedChildComponentTagName('RG1OU0i');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RG1OU0i');
} else {
    $response = \Livewire\Livewire::mount('posts');
    $html = $response->html();
    $_instance->logRenderedChild('RG1OU0i', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <a href="<?php echo e(route('bootstrap')); ?>">See Bootstrap version</a>
    </div>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>


</body>
</html>
<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/tailwind.blade.php ENDPATH**/ ?>