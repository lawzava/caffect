<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Posts: Generate Slug from Title</title>

    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
<div class="font-sans text-gray-900 antialiased">
    <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">
        <h2 class="font-bold text-4xl">Parent-Child Dependent Dropdowns</h2>

        <div class="w-full sm:max-w-xl mt-6 px-6 py-8 bg-white shadow-md overflow-hidden sm:rounded-lg">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('country-city')->html();
} elseif ($_instance->childHasBeenRendered('THMbyVj')) {
    $componentId = $_instance->getRenderedChildComponentId('THMbyVj');
    $componentTag = $_instance->getRenderedChildComponentTagName('THMbyVj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('THMbyVj');
} else {
    $response = \Livewire\Livewire::mount('country-city');
    $html = $response->html();
    $_instance->logRenderedChild('THMbyVj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>


</body>
</html>
<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/welcome.blade.php ENDPATH**/ ?>