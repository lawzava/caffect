<?php return array (
  'posts' => 'App\\Http\\Livewire\\Posts',
);