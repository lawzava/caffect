<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
<div id="app">
    <main class="py-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header"><h3>Parent-Child Dependent Dropdowns: Bootstrap Version</h3></div>

                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('companies', ['designTemplate' => 'bootstrap'])->html();
} elseif ($_instance->childHasBeenRendered('s3HybWV')) {
    $componentId = $_instance->getRenderedChildComponentId('s3HybWV');
    $componentTag = $_instance->getRenderedChildComponentTagName('s3HybWV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('s3HybWV');
} else {
    $response = \Livewire\Livewire::mount('companies', ['designTemplate' => 'bootstrap']);
    $html = $response->html();
    $_instance->logRenderedChild('s3HybWV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                    <div class="mt-3 text-center">
                        <a href="<?php echo e(route('tailwind')); ?>">See Tailwind version</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /Users/povilaskorop/Sites/tailwindkit/resources/views/bootstrap.blade.php ENDPATH**/ ?>