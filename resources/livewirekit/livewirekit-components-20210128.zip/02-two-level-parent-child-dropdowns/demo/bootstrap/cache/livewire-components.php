<?php return array (
  'companies' => 'App\\Http\\Livewire\\Companies',
);